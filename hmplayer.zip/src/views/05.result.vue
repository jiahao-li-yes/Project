<template>
  <div class="result-container">
    <div class="title-wrap">
      <h2 class="title">{{result}}</h2>
      <span class="sub-title">找到{{count}}个结果</span>
    </div>
    <el-tabs v-model="activeIndex">
      <el-tab-pane label="歌曲" name="songs">
        <table class="el-table">
          <thead>
            <th></th>
            <th>音乐标题</th>
            <th>歌手</th>
            <th>专辑</th>
            <th>时长</th>
          </thead>
          <tbody>
            <tr
              class="el-table__row"
              v-for="(item,index) in resultList"
              :key="index"
              @dblclick="doubleplay(item.id)"
            >
              <td>1</td>
              <td>
                <div class="song-wrap">
                  <div class="name-wrap">
                    <span>{{item.name}}</span>
                    <span class="iconfont icon-mv"></span>
                  </div>
                  <span v-if="item.alias.length!=0">{{item.alias[0]}}</span>
                </div>
              </td>
              <td>{{item.artists[0].name}}</td>
              <td>{{item.album.name}}</td>
              <td>{{item.duration}}</td>
            </tr>
          </tbody>
        </table>
      </el-tab-pane>
      <el-tab-pane label="歌单" name="lists">
        <div class="items">
          <div class="item" v-for="(item,index) in listgd" :key="index" @click="toPlaylist(item.id)">
            <div class="img-wrap">
              <div class="num-wrap">
                播放量:
                <span class="num">{{item.playCount}}</span>
              </div>
              <img :src="item.coverImgUrl" alt />
              <span class="iconfont icon-play"></span>
            </div>
            <p class="name">{{item.name}}</p>
          </div>
        </div>
      </el-tab-pane>
      <el-tab-pane label="MV" name="mv">
        <div class="items mv">
          <div class="item" v-for="(item,index) in listmv" :key="index" @click="toMV(item.id)">
            <div class="img-wrap">
              <img :src="item.cover" alt />
              <span class="iconfont icon-play"></span>
              <div class="num-wrap">
                <div class="iconfont icon-play"></div>
                <div class="num">{{item.playCount}}</div>
              </div>
              <span class="time">{{item.duration}}</span>
            </div>
            <div class="info-wrap">
              <div class="name">{{item.name}}</div>
              <div class="singer">{{item.artistName}}</div>
            </div>
          </div>
        </div>
      </el-tab-pane>
    </el-tabs>
  </div>
</template>

<script>
import axios from "axios";
export default {
  name: "result",
  data() {
    return {
      activeIndex: "songs",
      result: "",
      count: "",
      resultList: [],
      limit: "10",
      offset: "",
      type: "1",
      listgd: [],
      listmv: []
    };
  },
  watch: {
    activeIndex() {
      console.log(this.activeIndex);
      if (this.activeIndex == "songs") {
        this.type = 1;
        this.limit = 20
        this.getMusic(this.result)
      } else if (this.activeIndex == "lists") {
        this.type = 1000;
        this.limit = 10
        this.getList(this.result);
      } else if (this.activeIndex == "mv") {
        this.type = 1004;
        this.limit = 8
        this.getMv(this.result);
      }
    }
  },
  created() {
    this.result = this.$route.query.q;
    this.getMusic(this.result);
  },
  methods: {
    getMusic(keywords) {
      axios({
        url: "https://autumnfish.cn/search",
        method: "get",
        params: {
          keywords,
          limit: this.limit,
          offset: this.offset,
          type: this.type
        }
      }).then(res => {
        console.log(res);
        this.count = res.data.result.songCount;
        this.resultList = res.data.result.songs;

        // 处理时间
        this.handleTime(this.resultList)
      });
    },
    getList(keywords) {
      axios({
        url: "https://autumnfish.cn/search",
        method: "get",
        params: {
          keywords,
          limit: this.limit,
          offset: this.offset,
          type: this.type
        }
      }).then(res => {
        console.log(res);
        this.listgd = res.data.result.playlists
      });
    },
    getMv(keywords) {
      axios({
        url: "https://autumnfish.cn/search",
        method: "get",
        params: {
          keywords,
          limit: this.limit,
          offset: this.offset,
          type: this.type
        }
      }).then(res => {
        console.log(res);
        this.listmv = res.data.result.mvs
        this.handleTime(this.listmv)

        for(let i = 0; i < this.listmv.length;i++){
          if(this.listmv[i].playCount > 100000){
            this.listmv[i].playCount = parseInt(this.listmv[i].playCount/10000) + '万'
          }
        }
      });
    },
    doubleplay(id) {
      axios({
        url: "https://autumnfish.cn/song/url",
        method: "get",
        params: {
          id
        }
      }).then(res => {
        console.log(res);
        this.playurl = res.data.data[0].url;
        this.$parent.musicUrl = this.playurl;
      });
    },
    //处理时间
    handleTime(element){
      if (element.length > 0) {
          for (let i = 0; i < element.length; i++) {
            let duration = element[i].duration;
            let min = parseInt(duration / 1000 / 60);
            if (min < 10) {
              min = "0" + min;
            }
            let sec = parseInt((duration / 1000) % 60);
            if (sec < 10) {
              sec = "0" + sec;
            }
            // console.log(min + ":" + sec);
            element[i].duration = `${min}:${sec}`;
          }
        }
    },
    toPlaylist(id){
      this.$router.push(`/playlist?q=${id}`)
    },
    toMV(id){
      this.$router.push(`/mv?q=${id}`)
    }
  }
};
</script>

<style >
</style>
